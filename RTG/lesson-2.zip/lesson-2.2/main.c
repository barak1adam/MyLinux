#include <stdio.h>

int main()
{
	printf("hello world\n");
	func1();
	func2();
	return 0;
}

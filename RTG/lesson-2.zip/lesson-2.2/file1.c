#include "file1.h"
int func1()
{
	printf("func1()\n");
	return 0;
}

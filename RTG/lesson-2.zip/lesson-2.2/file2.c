#include "file2.h"
int func2()
{
	printf("func2()\n");
	return 0;
}

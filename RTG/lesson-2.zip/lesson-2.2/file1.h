#include <stdio.h>

int func1();

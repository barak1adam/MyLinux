#include <stdio.h>

int func2();
